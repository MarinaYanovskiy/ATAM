#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "aux_code.h"
#include "students_code.h"

int get_len();
void get_input(uint8_t* input, int len);
void get_key(uint8_t key[4][4]);